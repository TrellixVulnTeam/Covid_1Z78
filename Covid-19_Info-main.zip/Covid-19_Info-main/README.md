# Covid-19_Info
covid-19 world wide info. vanilla js, html, css. 

Link: https://gifted-williams-97b852.netlify.app/

#
![alt text](https://github.com/ArielMoi/Covid-19_Info/blob/main/img/screenShot.png)
#
![alt text](https://github.com/ArielMoi/Covid-19_Info/blob/main/img/screenShot1.png)
#

# Features:
- use of 2 APIs.
- Chart.js.
- info per country

#

// TODO:
- add more data on specific country

#
weekend project. 
practice use of multiple API.
use of external library.
